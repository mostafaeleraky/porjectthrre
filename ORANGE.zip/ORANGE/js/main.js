$(document).ready(function(){
$('.owl-carousel').owlCarousel({
    items:2,
    loop:true,
    margin:10,
    merge:true,
    responsive:{
        678:{
            mergeFit:true
        },
        1000:{
            mergeFit:2
        }
    }
});
});
$(document).ready(function(){
	  /* Demo purposes only */
  $("figure").mouseleave(
    function() {
      $(this).removeClass("hover");
    }
  );
});
/*$(document).ready(function(){*/
	var hoverItem = document.querySelector('.wrapper');

hoverItem.addEventListener('click', function(e) {
  e.preventDefault();
}, false);

hoverItem.addEventListener('mousemove', function(evt) {
  evt = (evt || event);
  
  hoverItem.style.backgroundPosition = (evt.clientX/20) + '%' + ' ' + (evt.clientY/20) + '%';
}, false);
/*});*/
	$(document).ready(function(){
$('.owl-carousel').owlCarousel({
    items:2,
    loop:true,
    margin:10,
    merge:true,
    responsive:{
        678:{
            mergeFit:2
        },
        1000:{
            mergeFit:1
        }
    }
});
});



